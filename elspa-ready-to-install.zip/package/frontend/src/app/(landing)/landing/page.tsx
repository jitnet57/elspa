'use client';

import { useState } from 'react';

export default function CustomerLandingPage() {
  const [isBookingOpen, setIsBookingOpen] = useState(false);

  const openBooking = () => {
    setIsBookingOpen(true);
    document.body.style.overflow = 'hidden';
  };

  const closeBooking = () => {
    setIsBookingOpen(false);
    document.body.style.overflow = 'auto';
  };

  const submitBooking = () => {
    alert('🎉 예약이 완료되었습니다!\n\n예약번호: #KR1025\n드라이버 추적은 마이페이지에서 확인하세요.');
    closeBooking();
  };

  return (
    <div>
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body {
          font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
          line-height: 1.6;
          color: #2c3e50;
          background: #f8f9fa;
        }

        .container {
          max-width: 100%;
          padding: 0;
        }

        nav {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 20px 24px;
          background: white;
          box-shadow: 0 2px 12px rgba(0,0,0,0.08);
          position: sticky;
          top: 0;
          z-index: 100;
        }

        .logo {
          font-size: 1.5em;
          font-weight: 700;
          color: #ff6b35;
          display: flex;
          align-items: center;
          gap: 8px;
        }

        .nav-icons {
          display: flex;
          gap: 20px;
          font-size: 1.2em;
        }

        nav a {
          cursor: pointer;
          color: #2c3e50;
        }

        .hero {
          background: linear-gradient(135deg, rgba(102, 126, 234, 0.95) 0%, rgba(118, 75, 162, 0.95) 100%),
                      url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 600"><rect fill="%23f5f7fa" width="1200" height="600"/><path fill="%23667eea" opacity="0.05" d="M0 0l300 200v200l-300 200V0z"/><path fill="%23764ba2" opacity="0.05" d="M900 0l300 200v200l-300 200V0z"/></svg>');
          background-size: cover;
          background-position: center;
          color: white;
          padding: 60px 24px;
          text-align: center;
          position: relative;
          overflow: hidden;
        }

        .hero::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: radial-gradient(circle at 20% 50%, rgba(255,107,53,0.1) 0%, transparent 50%);
          z-index: 1;
        }

        .hero-content {
          position: relative;
          z-index: 2;
        }

        .hero-badge {
          display: inline-block;
          background: rgba(255,107,53,0.9);
          color: white;
          padding: 8px 20px;
          border-radius: 20px;
          font-size: 0.85em;
          font-weight: 600;
          margin-bottom: 20px;
        }

        .hero h1 {
          font-size: 2.6em;
          font-weight: 700;
          margin-bottom: 16px;
          line-height: 1.3;
          letter-spacing: -0.8px;
          text-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }

        .hero-subtitle {
          font-size: 1.05em;
          margin-bottom: 40px;
          opacity: 0.98;
          line-height: 1.9;
          max-width: 95%;
          margin-left: auto;
          margin-right: auto;
          font-weight: 500;
        }

        .hero-cta {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          background: #ff6b35;
          color: white;
          padding: 14px 28px;
          border: none;
          border-radius: 8px;
          font-size: 1em;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.3s;
          margin-bottom: 40px;
        }

        .hero-cta:hover {
          background: #e55a24;
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(255, 107, 53, 0.3);
        }

        .hero-stats {
          display: flex;
          justify-content: space-around;
          margin-top: 40px;
          padding: 20px;
          background: rgba(255,255,255,0.1);
          border-radius: 12px;
          backdrop-filter: blur(10px);
        }

        .stat {
          text-align: center;
        }

        .stat-number {
          font-size: 1.8em;
          font-weight: 700;
          display: block;
        }

        .stat-label {
          font-size: 0.85em;
          opacity: 0.9;
          margin-top: 4px;
        }

        section {
          padding: 40px 24px;
        }

        section h2 {
          font-size: 1.8em;
          font-weight: 700;
          margin-bottom: 28px;
          color: #1a1a1a;
        }

        .step-indicator {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 32px;
          padding: 0 20px;
        }

        .step {
          width: 48px;
          height: 48px;
          border-radius: 50%;
          background: #f0f4ff;
          color: #667eea;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 700;
          font-size: 1.2em;
          border: 2px solid #e0e7ff;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .step.active {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border-color: #667eea;
          box-shadow: 0 4px 12px rgba(102, 126, 234, 0.25);
        }

        .step-line {
          flex: 1;
          height: 2px;
          background: #e0e7ff;
          margin: 0 16px;
          transition: all 0.3s;
        }

        .services-section {
          background: white;
        }

        .services-grid {
          display: flex;
          flex-direction: column;
          gap: 20px;
        }

        .service-card {
          background: white;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(102, 126, 234, 0.12);
          display: flex;
          gap: 0;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          border: 1px solid rgba(102, 126, 234, 0.08);
        }

        .service-card:active {
          transform: translateY(-4px);
          box-shadow: 0 12px 28px rgba(102, 126, 234, 0.18);
        }

        .service-image {
          width: 140px;
          height: 140px;
          flex-shrink: 0;
          position: relative;
          overflow: hidden;
          border-radius: 12px;
        }

        .service-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .service-image::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: rgba(0,0,0,0.15);
          z-index: 1;
        }

        .service-content {
          flex: 1;
          padding: 18px 20px;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
        }

        .service-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 8px;
        }

        .service-name {
          font-size: 1.15em;
          font-weight: 600;
          color: #1a1a1a;
        }

        .service-price {
          font-size: 1.3em;
          font-weight: 700;
          color: #ff6b35;
        }

        .service-meta {
          display: flex;
          gap: 12px;
          font-size: 0.85em;
          color: #666;
          margin-bottom: 8px;
        }

        .service-rating {
          color: #ffc107;
          font-size: 0.9em;
        }

        .service-description {
          font-size: 0.85em;
          color: #666;
          line-height: 1.5;
        }

        .featured-service {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          border-radius: 20px;
          padding: 0;
          overflow: hidden;
          margin-bottom: 20px;
          box-shadow: 0 8px 32px rgba(102, 126, 234, 0.25);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .featured-image {
          width: 100%;
          height: 240px;
          position: relative;
          overflow: hidden;
          border-radius: 16px;
        }

        .featured-image img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .featured-image::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
          z-index: 1;
        }

        .featured-image span {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          z-index: 2;
          font-size: 3em;
          text-shadow: 0 2px 8px rgba(0,0,0,0.3);
        }

        .featured-content {
          padding: 24px;
        }

        .featured-badge {
          display: inline-block;
          background: rgba(255,255,255,0.2);
          padding: 6px 14px;
          border-radius: 16px;
          font-size: 0.75em;
          font-weight: 600;
          margin-bottom: 12px;
        }

        .featured-name {
          font-size: 1.4em;
          font-weight: 700;
          margin-bottom: 8px;
        }

        .featured-duration {
          font-size: 0.95em;
          opacity: 0.9;
          margin-bottom: 12px;
        }

        .featured-price {
          font-size: 1.6em;
          font-weight: 700;
          margin-bottom: 12px;
        }

        .featured-description {
          font-size: 0.9em;
          line-height: 1.6;
          opacity: 0.95;
        }

        .why-us {
          background: white;
        }

        .why-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
        }

        .why-card {
          background: linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(248,249,250,0.95) 100%);
          padding: 28px 24px;
          border-radius: 16px;
          text-align: center;
          border: 1px solid rgba(102, 126, 234, 0.12);
          box-shadow: 0 2px 12px rgba(102, 126, 234, 0.08);
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .why-card:active {
          transform: translateY(-4px);
          box-shadow: 0 8px 20px rgba(102, 126, 234, 0.15);
        }

        .why-icon {
          font-size: 2.5em;
          margin-bottom: 12px;
        }

        .why-title {
          font-size: 1.05em;
          font-weight: 600;
          margin-bottom: 8px;
          color: #1a1a1a;
        }

        .why-text {
          color: #666;
          line-height: 1.6;
          font-size: 0.9em;
        }

        .therapists-grid {
          display: grid;
          grid-template-columns: 1fr;
          gap: 16px;
        }

        .therapist-card {
          background: white;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 4px 16px rgba(102, 126, 234, 0.12);
          display: flex;
          gap: 0;
          border: 1px solid rgba(102, 126, 234, 0.08);
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        .therapist-card:active {
          transform: translateY(-4px);
          box-shadow: 0 12px 28px rgba(102, 126, 234, 0.18);
        }

        .therapist-image {
          width: 110px;
          height: 110px;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          background-size: cover;
          background-position: center;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 2.5em;
          flex-shrink: 0;
          position: relative;
          border-radius: 8px;
          overflow: hidden;
        }

        .therapist-image::after {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background: linear-gradient(135deg, rgba(102, 126, 234, 0.1) 0%, rgba(118, 75, 162, 0.1) 100%);
        }

        .therapist-image span {
          position: relative;
          z-index: 2;
        }

        .therapist-info {
          flex: 1;
          padding: 16px;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }

        .therapist-name {
          font-size: 1.1em;
          font-weight: 600;
          color: #1a1a1a;
          margin-bottom: 4px;
        }

        .therapist-specialty {
          color: #ff6b35;
          font-size: 0.85em;
          font-weight: 500;
          margin-bottom: 8px;
        }

        .therapist-meta {
          color: #666;
          font-size: 0.85em;
        }

        .therapist-rating {
          color: #ffc107;
          font-size: 0.85em;
        }

        .reviews {
          background: #f8f9fa;
        }

        .review-card {
          background: white;
          padding: 24px;
          border-radius: 16px;
          margin-bottom: 16px;
          box-shadow: 0 2px 12px rgba(102, 126, 234, 0.08);
          border: 1px solid rgba(102, 126, 234, 0.08);
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          display: flex;
          gap: 16px;
        }

        .review-card:active {
          transform: translateY(-2px);
          box-shadow: 0 6px 16px rgba(102, 126, 234, 0.12);
        }

        .review-avatar {
          width: 56px;
          height: 56px;
          min-width: 56px;
          border-radius: 50%;
          overflow: hidden;
          box-shadow: 0 2px 8px rgba(0,0,0,0.12);
        }

        .review-avatar img {
          width: 100%;
          height: 100%;
          object-fit: cover;
        }

        .review-content {
          flex: 1;
        }

        .review-stars {
          color: #ffc107;
          font-size: 0.95em;
          margin-bottom: 8px;
          letter-spacing: 2px;
        }

        .review-text {
          color: #555;
          font-size: 0.9em;
          line-height: 1.7;
          margin-bottom: 12px;
          font-style: italic;
          font-weight: 500;
        }

        .review-author {
          font-weight: 600;
          color: #1a1a1a;
          font-size: 0.85em;
        }

        .newsletter {
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          color: white;
          text-align: center;
          padding: 48px 24px;
          border-radius: 20px;
          margin-bottom: 0;
          box-shadow: 0 8px 32px rgba(102, 126, 234, 0.25);
          border: 1px solid rgba(255, 255, 255, 0.1);
        }

        .newsletter h2 {
          color: white;
          margin-bottom: 12px;
        }

        .newsletter p {
          font-size: 0.95em;
          margin-bottom: 24px;
          opacity: 0.95;
        }

        .newsletter-form {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .newsletter-form input {
          padding: 14px 18px;
          border: 2px solid rgba(255, 255, 255, 0.2);
          border-radius: 10px;
          font-size: 0.95em;
          background: rgba(255, 255, 255, 0.95);
          transition: all 0.3s;
        }

        .newsletter-form input:focus {
          outline: none;
          border-color: white;
          background: white;
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .newsletter-form input::placeholder {
          color: #999;
        }

        .newsletter-btn {
          padding: 14px 32px;
          background: #ff6b35;
          color: white;
          border: none;
          border-radius: 10px;
          font-weight: 600;
          font-size: 0.95em;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 4px 12px rgba(255, 107, 53, 0.25);
        }

        .newsletter-btn:active {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(255, 107, 53, 0.35);
        }

        .bottom-nav {
          position: fixed;
          bottom: 0;
          left: 0;
          right: 0;
          background: white;
          border-top: 1px solid #e0e0e0;
          display: flex;
          justify-content: space-around;
          padding: 12px 0;
          z-index: 99;
        }

        .nav-item {
          flex: 1;
          text-align: center;
          padding: 8px;
          cursor: pointer;
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 4px;
          color: #999;
          text-decoration: none;
          font-size: 0.75em;
          transition: color 0.3s;
        }

        .nav-item.active {
          color: #ff6b35;
        }

        .nav-item-icon {
          font-size: 1.5em;
        }

        .nav-spacer {
          height: 80px;
        }

        footer {
          background: #1a1a1a;
          color: #ccc;
          padding: 24px;
          text-align: center;
          font-size: 0.9em;
        }

        .modal {
          display: none;
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          background: rgba(0,0,0,0.6);
          z-index: 2000;
          justify-content: center;
          align-items: flex-end;
        }

        .modal.active {
          display: flex;
        }

        .modal-content {
          background: white;
          width: 100%;
          max-height: 90vh;
          border-radius: 20px 20px 0 0;
          padding: 28px 24px;
          overflow-y: auto;
          animation: slideUp 0.3s ease-out;
          box-shadow: 0 -4px 20px rgba(0,0,0,0.08);
        }

        .modal-content h2 {
          color: #1a1a1a;
          font-size: 1.8em;
          margin-bottom: 24px;
        }

        @keyframes slideUp {
          from {
            transform: translateY(100%);
          }
          to {
            transform: translateY(0);
          }
        }

        .modal-close {
          position: absolute;
          top: 20px;
          right: 20px;
          background: rgba(102, 126, 234, 0.1);
          border: none;
          width: 40px;
          height: 40px;
          border-radius: 50%;
          font-size: 1.6em;
          cursor: pointer;
          color: #667eea;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.3s;
        }

        .modal-close:active {
          background: rgba(102, 126, 234, 0.2);
          transform: scale(0.95);
        }

        .form-group {
          margin-bottom: 20px;
        }

        .form-group label {
          display: block;
          margin-bottom: 8px;
          font-weight: 600;
          color: #1a1a1a;
          font-size: 0.95em;
        }

        .form-group input,
        .form-group select {
          width: 100%;
          padding: 14px 16px;
          border: 2px solid #e0e7ff;
          border-radius: 10px;
          font-size: 1em;
          font-family: inherit;
          transition: all 0.3s;
          background: white;
        }

        .form-group input:focus,
        .form-group select:focus {
          outline: none;
          border-color: #ff6b35;
          box-shadow: 0 0 0 4px rgba(255, 107, 53, 0.12);
          background: white;
        }

        .form-group input::placeholder {
          color: #999;
        }

        .booking-btn {
          width: 100%;
          padding: 16px;
          background: linear-gradient(135deg, #ff6b35 0%, #e55a24 100%);
          color: white;
          border: none;
          border-radius: 10px;
          font-weight: 700;
          font-size: 1.05em;
          cursor: pointer;
          transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          box-shadow: 0 4px 12px rgba(255, 107, 53, 0.25);
        }

        .booking-btn:active {
          transform: translateY(-2px);
          box-shadow: 0 8px 20px rgba(255, 107, 53, 0.35);
        }

        @media (max-width: 480px) {
          .hero h1 {
            font-size: 2.2em;
          }

          section h2 {
            font-size: 1.6em;
          }

          .why-grid {
            grid-template-columns: 1fr;
          }
        }
      `}</style>

      {/* Navigation */}
      <nav>
        <div className="logo">🧖‍♀️ ELSPA</div>
        <div className="nav-icons">
          <a href="#">🔍</a>
          <a href="#">👤</a>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <div className="hero-badge">✨ BOOK NOW</div>
          <h1>Your Journey to<br />Serenity</h1>
          <p className="hero-subtitle">프리미엄 테라피스트와 함께하는<br />최고의 웰니스 경험</p>
          <button className="hero-cta" onClick={openBooking}>📅 Book Now →</button>
          <div className="hero-stats">
            <div className="stat">
              <span className="stat-number">⭐ 4.9</span>
              <span className="stat-label">Rating</span>
            </div>
            <div className="stat">
              <span className="stat-number">1.2K+</span>
              <span className="stat-label">Reviews</span>
            </div>
            <div className="stat">
              <span className="stat-number">10+</span>
              <span className="stat-label">Experts</span>
            </div>
          </div>
        </div>
      </section>

      {/* Step Indicator */}
      <section style={{ background: 'white', padding: '20px 0' }}>
        <div className="step-indicator">
          <div className="step active">1</div>
          <div className="step-line"></div>
          <div className="step">2</div>
          <div className="step-line"></div>
          <div className="step">3</div>
        </div>
        <div style={{ textAlign: 'center', padding: '0 24px' }}>
          <p style={{ color: '#666', fontSize: '0.9em' }}>
            <strong>예약 선택</strong> • <strong>테라피스트 선택</strong> • <strong>예약 완료</strong>
          </p>
        </div>
      </section>

      {/* Services Section */}
      <section className="services-section">
        <h2>추천 코스</h2>

        {/* Featured Service */}
        <div className="featured-service">
          <div className="featured-image">
            <picture>
              <source srcSet="/images/facilities/facilities_1.webp" type="image/webp" />
              <img src="/images/facilities/facilities_1.jpg" alt="Swedish Massage Service" />
            </picture>
            <span>💆‍♀️</span>
          </div>
          <div className="featured-content">
            <span className="featured-badge">✨ BEST SELLER</span>
            <div className="featured-name">Swedish Relaxation</div>
            <div className="featured-duration">⏱️ 60분</div>
            <div className="featured-price">₱180,000</div>
            <div className="featured-description">깊고 강한 압력으로 근육의 긴장을 풀어주는 최고의 이완 마사지. 스트레스 해소와 혈액 순환 개선에 최적화된 프리미엄 코스입니다.</div>
          </div>
        </div>

        {/* Other Services */}
        <div className="service-card">
          <div className="service-image">
            <picture>
              <source srcSet="/images/services/services_1.webp" type="image/webp" />
              <img src="/images/services/services_1.jpg" alt="Traditional Thai Massage" />
            </picture>
          </div>
          <div className="service-content">
            <div className="service-header">
              <div className="service-name">Traditional Thai</div>
              <div className="service-price">₱220K</div>
            </div>
            <div className="service-meta">
              <span>⏱️ 90분</span>
              <span className="service-rating">⭐ 4.8</span>
            </div>
            <div className="service-description">전통 타이 마사지로 몸과 마음을 동시에 이완하는 경험</div>
          </div>
        </div>

        <div className="service-card">
          <div className="service-image">
            <picture>
              <source srcSet="/images/services/services_2.webp" type="image/webp" />
              <img src="/images/services/services_2.jpg" alt="Hot Stone Therapy" />
            </picture>
          </div>
          <div className="service-content">
            <div className="service-header">
              <div className="service-name">Hot Stone Therapy</div>
              <div className="service-price">₱200K</div>
            </div>
            <div className="service-meta">
              <span>⏱️ 60분</span>
              <span className="service-rating">⭐ 4.7</span>
            </div>
            <div className="service-description">따뜻한 돌로 혈액 순환을 촉진하는 프리미엄 테라피</div>
          </div>
        </div>

        <div className="service-card">
          <div className="service-image">
            <picture>
              <source srcSet="/images/services/services_3.webp" type="image/webp" />
              <img src="/images/services/services_3.jpg" alt="Foot Reflexology" />
            </picture>
          </div>
          <div className="service-content">
            <div className="service-header">
              <div className="service-name">Foot Reflexology</div>
              <div className="service-price">₱80K</div>
            </div>
            <div className="service-meta">
              <span>⏱️ 30분</span>
              <span className="service-rating">⭐ 4.9</span>
            </div>
            <div className="service-description">발의 피로를 풀어주는 리프레싱 반사 요법 마사지</div>
          </div>
        </div>
      </section>

      {/* Why Us */}
      <section className="why-us">
        <h2>왜 ELSPA인가?</h2>
        <div className="why-grid">
          <div className="why-card">
            <div className="why-icon">🏆</div>
            <div className="why-title">전문가 팀</div>
            <div className="why-text">10년+ 경력의 검증된 전문가</div>
          </div>
          <div className="why-card">
            <div className="why-icon">🚗</div>
            <div className="why-title">픽업 서비스</div>
            <div className="why-text">24시간 안전한 픽업/드롭</div>
          </div>
          <div className="why-card">
            <div className="why-icon">💯</div>
            <div className="why-title">만족도 보장</div>
            <div className="why-text">아니면 100% 환불</div>
          </div>
          <div className="why-card">
            <div className="why-icon">🛡️</div>
            <div className="why-title">완벽한 안전</div>
            <div className="why-text">프라이버시 & 보안</div>
          </div>
        </div>
      </section>

      {/* Therapists */}
      <section>
        <h2>프리미엄 테라피스트</h2>
        <div className="therapists-grid">
          <div className="therapist-card">
            <div className="therapist-image"><span>👩‍💼</span></div>
            <div className="therapist-info">
              <div className="therapist-name">Sarah Johnson</div>
              <div className="therapist-specialty">🏅 Swedish Specialist</div>
              <div className="therapist-meta">
                <div className="therapist-rating">⭐ 4.9 (156 예약)</div>
                <div style={{ color: '#999', fontSize: '0.8em' }}>7년 경력 • 신뢰도 99%</div>
              </div>
            </div>
          </div>

          <div className="therapist-card">
            <div className="therapist-image"><span>👩‍💼</span></div>
            <div className="therapist-info">
              <div className="therapist-name">Emma Chen</div>
              <div className="therapist-specialty">🌴 Thai Massage Expert</div>
              <div className="therapist-meta">
                <div className="therapist-rating">⭐ 4.8 (128 예약)</div>
                <div style={{ color: '#999', fontSize: '0.8em' }}>5년 경력 • 신뢰도 98%</div>
              </div>
            </div>
          </div>

          <div className="therapist-card">
            <div className="therapist-image"><span>👩‍💼</span></div>
            <div className="therapist-info">
              <div className="therapist-name">Jessica Lee</div>
              <div className="therapist-specialty">🌿 Holistic Therapist</div>
              <div className="therapist-meta">
                <div className="therapist-rating">⭐ 4.7 (167 예약)</div>
                <div style={{ color: '#999', fontSize: '0.8em' }}>8년 경력 • 신뢰도 100%</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="reviews">
        <h2>고객 후기</h2>
        <div className="review-card">
          <div className="review-avatar">
            <picture>
              <source srcSet="/images/reviews/reviews_1.webp" type="image/webp" />
              <img src="/images/reviews/reviews_1.jpg" alt="Min-ji Kim" />
            </picture>
          </div>
          <div className="review-content">
            <div className="review-stars">⭐⭐⭐⭐⭐</div>
            <p className="review-text">"정말 최고의 경험이었어요! 모든 것이 완벽했습니다."</p>
            <div className="review-author">Min-ji Kim</div>
          </div>
        </div>

        <div className="review-card">
          <div className="review-avatar">
            <picture>
              <source srcSet="/images/reviews/reviews_2.webp" type="image/webp" />
              <img src="/images/reviews/reviews_2.jpg" alt="Jun-ho Lee" />
            </picture>
          </div>
          <div className="review-content">
            <div className="review-stars">⭐⭐⭐⭐⭐</div>
            <p className="review-text">"전문성과 친절함이 최고예요. 다시 꼭 방문하겠습니다!"</p>
            <div className="review-author">Jun-ho Lee</div>
          </div>
        </div>

        <div className="review-card">
          <div className="review-avatar">
            <picture>
              <source srcSet="/images/reviews/reviews_3.webp" type="image/webp" />
              <img src="/images/reviews/reviews_3.jpg" alt="Su-jin Park" />
            </picture>
          </div>
          <div className="review-content">
            <div className="review-stars">⭐⭐⭐⭐⭐</div>
            <p className="review-text">"가성비도 좋고 픽업 서비스도 최고네요. 추천합니다!"</p>
            <div className="review-author">Su-jin Park</div>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section style={{ padding: '40px 24px 100px' }}>
        <div className="newsletter">
          <h2 style={{ marginBottom: '8px' }}>특가 소식을 먼저 받으세요!</h2>
          <p style={{ marginBottom: '20px' }}>지금 가입하면 <strong>첫 예약 10% 할인</strong> 쿠폰</p>
          <div className="newsletter-form">
            <input type="email" placeholder="이메일을 입력하세요" required />
            <button className="newsletter-btn">✉️ Subscribe</button>
          </div>
        </div>
      </section>

      {/* Bottom Navigation */}
      <div className="bottom-nav">
        <a className="nav-item active" href="#">
          <div className="nav-item-icon">🏠</div>
          <div>홈</div>
        </a>
        <a className="nav-item" href="#">
          <div className="nav-item-icon">🔍</div>
          <div>검색</div>
        </a>
        <a className="nav-item" href="#" onClick={(e) => { e.preventDefault(); openBooking(); }}>
          <div className="nav-item-icon">📅</div>
          <div>예약</div>
        </a>
        <a className="nav-item" href="#">
          <div className="nav-item-icon">👤</div>
          <div>마이</div>
        </a>
      </div>

      {/* Booking Modal */}
      <div className={`modal ${isBookingOpen ? 'active' : ''}`} onClick={(e) => e.target === e.currentTarget && closeBooking()}>
        <div className="modal-content">
          <button className="modal-close" onClick={closeBooking}>✕</button>
          <h2 style={{ marginTop: '20px', marginBottom: '24px' }}>예약하기</h2>

          <div className="form-group">
            <label>1️⃣ 서비스 선택</label>
            <select required>
              <option value="">-- 원하는 서비스를 선택하세요 --</option>
              <option value="">Swedish Massage (60분) - ₱180,000</option>
              <option value="">Traditional Thai (90분) - ₱220,000</option>
              <option value="">Hot Stone Therapy (60분) - ₱200,000</option>
              <option value="">Foot Massage (30분) - ₱80,000</option>
            </select>
          </div>

          <div className="form-group">
            <label>2️⃣ 테라피스트 선택</label>
            <select required>
              <option value="">-- 자동 배정 또는 선택 --</option>
              <option value="">Sarah Johnson (⭐ 4.9)</option>
              <option value="">Emma Chen (⭐ 4.8)</option>
              <option value="">Jessica Lee (⭐ 4.7)</option>
            </select>
          </div>

          <div className="form-group">
            <label>3️⃣ 날짜 선택</label>
            <input type="date" required />
          </div>

          <div className="form-group">
            <label>⏰ 시간 선택</label>
            <select required>
              <option value="">-- 시간을 선택하세요 --</option>
              <option value="">14:00</option>
              <option value="">15:30</option>
              <option value="">17:00</option>
              <option value="">18:30</option>
              <option value="">20:00</option>
            </select>
          </div>

          <div className="form-group">
            <label>📍 주소</label>
            <input type="text" placeholder="예: 강남구 도곡동" required />
          </div>

          <button className="booking-btn" onClick={submitBooking}>예약 완료</button>
        </div>
      </div>

      <div className="nav-spacer"></div>
    </div>
  );
}
